"""主函数：初始化服务并启动多线程运行Flask和命令行菜单"""
import threading
import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from flask import Flask, send_from_directory
from flask_cors import CORS
from app.api import init_api
from app.services.SM2_Utils import SM2Service
from app.services.SM4_Utils import SM4Service
from app.routes import register_blueprints
from app.extensions import db

# ========== 初始化数据库 ==========
engine = create_engine('sqlite:///user.db')
Base = declarative_base()

# ========== 初始化Flask应用 ==========
app = Flask(__name__)

# 配置数据库
ecommerce_db = os.environ.get('APP_ECOMMERCE_DB_PATH')
app.config['SQLALCHEMY_DATABASE_URI'] = (
    'sqlite:///' + os.path.abspath(ecommerce_db).replace('\\', '/')
    if ecommerce_db else 'sqlite:///user.db'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_size': 16, 'max_overflow': 16, 'pool_timeout': 30,
    'connect_args': {'timeout': 30},
}

# 初始化 SQLAlchemy
db.init_app(app)

CORS(app, resources={r"/api/*": {"origins": "*"}})
init_api(app)
register_blueprints(app)

if os.environ.get('APP_METRICS_FILE'):
    from app.monitoring import install_monitoring
    install_monitoring(app, db)

# ========== 静态文件服务（图片上传） ==========
upload_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), 'uploads'))
os.makedirs(upload_folder, exist_ok=True)

@app.route('/week4-demo')
def week4_demo():
    return send_from_directory(os.path.join(os.path.dirname(__file__), 'evidence', 'week4'), 'demo.html')

@app.route('/evidence/week4/<path:filename>')
def week4_evidence(filename):
    return send_from_directory(os.path.join(os.path.dirname(__file__), 'evidence', 'week4'), filename)

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    print(f"[DEBUG] 请求文件: {filename}")
    print(f"[DEBUG] 完整路径: {os.path.join(upload_folder, filename)}")
    print(f"[DEBUG] 文件是否存在: {os.path.exists(os.path.join(upload_folder, filename))}")
    return send_from_directory(upload_folder, filename)

# ========== 初始化国密服务（替换原RSA初始化） ==========
def init_crypto_services():
    print("初始化国密SM2/SM3/SM4加密服务...")
    # 预加载SM2/SM4密钥（首次运行自动生成）
    sm2_service = SM2Service()
    sm4_service = SM4Service()
    print("✅ 国密加密服务初始化成功")

# ========== 初始化电商数据表 ==========
def init_ecommerce_db():
    try:
        from init_ecommerce_db import init_ecommerce_tables
        init_ecommerce_tables()
    except Exception as e:
        print(f"⚠️ 电商数据表初始化警告: {e}")

# ========== 初始化证书数据表 ==========
def init_certificates_db():
    try:
        from create_certificates_table import create_certificates_table
        if create_certificates_table():
            print("✅ 证书数据表初始化成功")
        else:
            print("⚠️ 证书数据表初始化失败")
    except Exception as e:
        print(f"⚠️ 证书数据表初始化警告: {e}")

# ========== Flask启动函数 ==========
def run_flask():
    app.run(host='0.0.0.0', port=5000, debug=False)

# ========== 命令行菜单（保留原逻辑） ==========
def cli_menu():
    while True:
        print("\n=== 电子商务系统管理菜单 ===")
        print("1. 用户注册")
        print("2. 退出系统")
        choice = input("请选择操作（1/2）：")
        if choice == "1":
            from app.services.register import register
            register()
        elif choice == "2":
            print(" 系统已退出")
            exit(0)
        else:
            print("❌ 无效选择，请重新输入")

# ========== 主函数 ==========
def main():
    try:
        # 初始化国密加密服务
        init_crypto_services()

        # 初始化数据库表
        print("初始化数据库...")

        # 使用 Flask-SQLAlchemy 创建所有模型表
        with app.app_context():
            db.create_all()
            print("✅ SQLAlchemy 模型表创建成功")

        # 初始化电商数据表
        init_ecommerce_db()

        # 初始化证书数据表
        init_certificates_db()

        # 多线程同时运行Flask服务和命令行菜单
        flask_thread = threading.Thread(target=run_flask)
        flask_thread.daemon = True
        flask_thread.start()

        print("=" * 60)
        print(" 电子商务系统启动成功!")
        print("=" * 60)

        # 启动命令行菜单
        cli_menu()

    except Exception as e:
        print(f"❌ 系统启动失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
